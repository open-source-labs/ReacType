/* input component
input component
button component
*/
import React from 'react';


const ContextMenu = () => {
  return (
    <h1>This is from context menu</h1>
  )
}

export default ContextMenu;