export default {
  neonGreen: 'rgb(51, 235, 145)',
  darkBlue: 'rgb(0, 0, 26)',
  darkGray: '#252526',
  tutorialGray: '#f2f0f0'
};
