export default {
  deleteIndexTitle: 'You cannot delete index.',
  deleteIndexMessage: 'You must have at least one page.',
  deleteComponentTitle: 'You cannot delete this component.',
  deleteComponentMessage: 'Reusable components inside of a page must be deleted from the page.',
  deleteLinkedPageTitle: 'Delete linked page error.',
  deleteLinkedPageMessage: 'Please delete the links to this page before deleting the page.'

}