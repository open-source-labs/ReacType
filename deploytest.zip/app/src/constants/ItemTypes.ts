import { DragItemType } from '../interfaces/Interfaces';
const ItemTypes: DragItemType = {
  INSTANCE: 'instance'
};
export { ItemTypes };
