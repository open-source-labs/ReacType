export default {
  neonGreen: '#189bd7',
  darkBlue: '#0671e3',
  darkGray: '#252526',
  tutorialGray: '#f2f0f0'
};
