export {};
declare global {
  interface Window {
    api: any;
  }
}

let { api } = window;
